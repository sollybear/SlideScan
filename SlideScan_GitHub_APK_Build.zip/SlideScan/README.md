# SlideScan

Hands-free Android slide scanner.

## What it does
- Watches the rear camera for a meaningful slide change.
- Waits for the new image to become stable.
- Rejects an unchanged slide.
- Automatically takes a full-resolution photograph.
- Crops/resizes the capture to 1920 × 1080 (16:9).
- Saves sequential JPEGs to `Pictures/SlideScan`.
- Beeps and vibrates after each successful capture.

## Build
1. Install Android Studio.
2. Open the `SlideScan` folder.
3. Let Gradle sync.
4. Connect your Android phone with USB debugging enabled, or build:
   **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
5. Install the generated APK on your phone.

## Use
1. Mount/hold the phone so the presentation fills the camera preview.
2. Tap **START SCANNING**.
3. Leave each slide visible for about one second.
4. After the beep/vibration, advance to the next slide.
5. Images appear in Gallery under `Pictures/SlideScan`.

## Sensitivity
The slider controls how different a new frame must be from the previous captured slide.
Lower = more sensitive. Higher = less sensitive.

## v1 limitation
The v1 build performs a clean 16:9 centre crop rather than four-corner perspective
rectification. This is deliberate: automatic perspective correction without a reliable
screen-boundary detector can destroy slides when presentation screens have low-contrast
edges. For best results, position the phone square-on and fill the preview with the slide.

## Automatic APK build with GitHub Actions

This project includes `.github/workflows/build-apk.yml`.

1. Create a new GitHub repository.
2. Upload/push the contents of the `SlideScan` folder to the repository root.
3. Open the repository's **Actions** tab.
4. Choose **Build SlideScan APK** and click **Run workflow**.
5. When the run finishes, open it and download the artifact named **SlideScan-debug-apk**.
6. Unzip the artifact and install `app-debug.apk` on your Android phone. Android may ask you to allow installation from the app you use to open the APK.

The workflow also builds automatically whenever the project is pushed to `main` or `master`.
