package com.slidescan.app

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.*
import android.media.ToneGenerator
import android.media.AudioManager
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.MediaStore
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.slidescan.app.databinding.ActivityMainBinding
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors
import kotlin.math.abs

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val executor = Executors.newSingleThreadExecutor()
    private var scanning = false
    private var count = 0
    private var lastSignature: IntArray? = null
    private var candidateSignature: IntArray? = null
    private var candidateSince = 0L
    private var lastCaptureAt = 0L
    private var imageCapture: ImageCapture? = null

    private val permission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { if (it) startCamera() else binding.statusText.text = "Camera permission is required." }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.startStopButton.setOnClickListener {
            scanning = !scanning
            binding.startStopButton.text = if (scanning) "STOP SCANNING" else "START SCANNING"
            binding.statusText.text = if (scanning)
                "Watching for the next stable slide…"
            else "Paused."
            candidateSignature = null
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED) startCamera()
        else permission.launch(Manifest.permission.CAMERA)
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(binding.previewView.surfaceProvider)
            }
            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .build()
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
            analysis.setAnalyzer(executor) { image -> analyze(image) }

            provider.unbindAll()
            provider.bindToLifecycle(
                this, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture, analysis
            )
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyze(image: ImageProxy) {
        if (!scanning) { image.close(); return }
        val sig = luminanceSignature(image)
        image.close()

        val previous = lastSignature
        if (previous == null) {
            candidateSignature = sig
            if (candidateSince == 0L) candidateSince = System.currentTimeMillis()
            if (System.currentTimeMillis() - candidateSince > 1000) capture(sig)
            return
        }

        val difference = distance(previous, sig)
        val threshold = binding.sensitivity.progress.coerceAtLeast(4) / 100.0
        val now = System.currentTimeMillis()

        if (difference > threshold && now - lastCaptureAt > 1200) {
            val candidate = candidateSignature
            if (candidate == null || distance(candidate, sig) > 0.025) {
                candidateSignature = sig
                candidateSince = now
                runOnUiThread { binding.statusText.text = "Change detected — waiting for slide to settle…" }
            } else if (now - candidateSince > 700) {
                capture(sig)
            }
        } else {
            candidateSignature = null
            candidateSince = 0L
            runOnUiThread { binding.statusText.text = "Watching for the next stable slide…" }
        }
    }

    private fun luminanceSignature(image: ImageProxy): IntArray {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        val w = image.width
        val h = image.height
        val gridX = 16
        val gridY = 9
        val out = IntArray(gridX * gridY)
        for (gy in 0 until gridY) {
            for (gx in 0 until gridX) {
                val x = ((gx + .5) * w / gridX).toInt().coerceIn(0, w - 1)
                val y = ((gy + .5) * h / gridY).toInt().coerceIn(0, h - 1)
                val pos = y * rowStride + x * pixelStride
                out[gy * gridX + gx] = buffer.get(pos).toInt() and 0xff
            }
        }
        return out
    }

    private fun distance(a: IntArray, b: IntArray): Double {
        var sum = 0.0
        for (i in a.indices) sum += abs(a[i] - b[i]) / 255.0
        return sum / a.size
    }

    private fun capture(signature: IntArray) {
        val capture = imageCapture ?: return
        lastCaptureAt = System.currentTimeMillis()
        candidateSignature = null
        candidateSince = 0L

        capture.takePicture(executor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                try {
                    val bytes = imageToJpeg(image)
                    image.close()
                    val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    val corrected = centerCrop16x9(bitmap, 1920, 1080)
                    saveBitmap(corrected)
                    bitmap.recycle()
                    if (corrected !== bitmap) corrected.recycle()
                    lastSignature = signature
                    count++
                    confirm()
                } catch (e: Exception) {
                    image.close()
                    runOnUiThread { binding.statusText.text = "Capture failed: ${e.message}" }
                }
            }
        })
    }

    private fun imageToJpeg(image: ImageProxy): ByteArray {
        if (image.format == ImageFormat.JPEG) {
            val buffer = image.planes[0].buffer
            val bytes = ByteArray(buffer.remaining())
            buffer.get(bytes)
            return bytes
        }
        throw IllegalStateException("Camera did not return JPEG")
    }

    private fun centerCrop16x9(src: Bitmap, targetW: Int, targetH: Int): Bitmap {
        val targetRatio = 16f / 9f
        val srcRatio = src.width.toFloat() / src.height
        val cropW: Int
        val cropH: Int
        if (srcRatio > targetRatio) {
            cropH = src.height
            cropW = (cropH * targetRatio).toInt()
        } else {
            cropW = src.width
            cropH = (cropW / targetRatio).toInt()
        }
        val x = (src.width - cropW) / 2
        val y = (src.height - cropH) / 2
        val cropped = Bitmap.createBitmap(src, x, y, cropW, cropH)
        return Bitmap.createScaledBitmap(cropped, targetW, targetH, true).also {
            if (it !== cropped) cropped.recycle()
        }
    }

    private fun saveBitmap(bitmap: Bitmap) {
        val name = "Slide_%03d.jpg".format(count + 1)
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/SlideScan")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Could not create image")
        contentResolver.openOutputStream(uri).use {
            bitmap.compress(Bitmap.CompressFormat.JPEG, 95, it!!)
        }
    }

    private fun confirm() {
        runOnUiThread {
            binding.countText.text = "Captured: $count"
            binding.statusText.text = "Slide $count captured ✓ — move to the next slide."
            ToneGenerator(AudioManager.STREAM_NOTIFICATION, 90)
                .startTone(ToneGenerator.TONE_PROP_BEEP, 180)
            val vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
            vibrator.vibrate(VibrationEffect.createOneShot(120, VibrationEffect.DEFAULT_AMPLITUDE))
        }
    }
}
